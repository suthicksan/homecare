
const TermsAndPolicy = () => {
  return (
    <div className="text-center text-sm text-gray-500 dark:text-gray-400">
      By booking a service, you agree to our <a href="#" className="text-primary hover:underline">Terms of Service</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>.
    </div>
  );
};

export default TermsAndPolicy;
