
import { Button } from "@/components/ui/button";

interface LocationDateStepProps {
  onBack: () => void;
  onContinue: () => void;
}

const LocationDateStep = ({ onBack, onContinue }: LocationDateStepProps) => {
  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Location & Date</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium mb-2">Your Address</label>
          <input 
            type="text" 
            className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary/50"
            placeholder="Enter your address"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-2">Service Date</label>
          <input 
            type="date" 
            className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-2">City</label>
          <input 
            type="text" 
            className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary/50"
            placeholder="Enter your city"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-2">Preferred Time</label>
          <select 
            className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option>Morning (8AM - 12PM)</option>
            <option>Afternoon (12PM - 4PM)</option>
            <option>Evening (4PM - 8PM)</option>
          </select>
        </div>
      </div>
      
      <div className="mt-8 flex justify-between">
        <Button 
          variant="outline"
          onClick={onBack}
        >
          Back
        </Button>
        <Button onClick={onContinue}>
          Continue
        </Button>
      </div>
    </div>
  );
};

export default LocationDateStep;
