
export const serviceOptions = [
  { id: "cleaning", label: "Cleaning" },
  { id: "plumbing", label: "Plumbing" },
  { id: "electrical", label: "Electrical" },
  { id: "landscaping", label: "Landscaping" },
  { id: "assembly", label: "Furniture Assembly" },
  { id: "painting", label: "Painting" },
];
