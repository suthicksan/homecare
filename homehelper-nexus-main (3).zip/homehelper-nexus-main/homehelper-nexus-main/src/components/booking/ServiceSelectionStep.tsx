
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface ServiceOption {
  id: string;
  label: string;
}

interface ServiceSelectionStepProps {
  serviceOptions: ServiceOption[];
  selectedService: string | null;
  setSelectedService: (service: string) => void;
  onContinue: () => void;
}

const ServiceSelectionStep = ({
  serviceOptions,
  selectedService,
  setSelectedService,
  onContinue,
}: ServiceSelectionStepProps) => {
  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Select a Service</h3>
      
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {serviceOptions.map((service) => (
          <button
            key={service.id}
            className={cn(
              "p-4 rounded-lg border text-center transition-all",
              selectedService === service.id
                ? "border-primary bg-primary/5 text-primary"
                : "border-gray-200 dark:border-gray-700 hover:border-primary/50"
            )}
            onClick={() => setSelectedService(service.id)}
          >
            <span className="text-sm font-medium">{service.label}</span>
          </button>
        ))}
      </div>
      
      <div className="mt-8 flex justify-end">
        <Button 
          disabled={!selectedService}
          onClick={onContinue}
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default ServiceSelectionStep;
