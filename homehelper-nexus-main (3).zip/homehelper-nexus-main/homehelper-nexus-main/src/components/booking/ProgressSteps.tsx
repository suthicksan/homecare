
import { cn } from "@/lib/utils";

interface ProgressStepsProps {
  currentStep: number;
  totalSteps: number;
}

const ProgressSteps = ({ currentStep, totalSteps }: ProgressStepsProps) => {
  return (
    <div className="flex justify-between items-center mb-8">
      {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
        <div key={step} className="flex items-center">
          <div 
            className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center font-medium text-sm transition-colors",
              currentStep >= step 
                ? "bg-primary text-white" 
                : "bg-gray-100 dark:bg-gray-800 text-gray-500"
            )}
          >
            {step}
          </div>
          {step < totalSteps && (
            <div className={cn(
              "h-1 w-24 md:w-36 mx-2",
              currentStep > step ? "bg-primary" : "bg-gray-200 dark:bg-gray-700"
            )}></div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ProgressSteps;
