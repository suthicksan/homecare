
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const stats = [
  { value: "10k+", label: "Happy Customers" },
  { value: "5,000+", label: "Projects Completed" },
  { value: "98%", label: "Customer Satisfaction" },
  { value: "200+", label: "Expert Professionals" }
];

const AboutPreview = () => {
  return (
    <section className="py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <AnimatedCard>
            <div className="relative">
              <div className="rounded-xl overflow-hidden shadow-2xl bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <div className="aspect-w-4 aspect-h-3 h-[400px] w-full relative">
                  <img 
                    src="https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=1000&auto=format&fit=crop" 
                    alt="Our team at work" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="absolute -right-4 -bottom-4 glass-card p-6 rounded-lg shadow-lg max-w-xs">
                <div className="grid grid-cols-2 gap-4">
                  {stats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className="text-primary text-2xl font-bold">{stat.value}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </AnimatedCard>
          
          <AnimatedCard delay={200}>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">About Our Company</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Started in 2010, we've grown from a small local business to a trusted name in home services across the country. Our mission is to make quality home care accessible to everyone.
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                We believe in transparency, reliability, and exceptional service. Every professional on our platform is thoroughly vetted and trained to deliver the highest quality work.
              </p>
              
              <div className="mt-8">
                <Button asChild>
                  <Link to="/about">
                    Learn More About Us
                    <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Link>
                </Button>
              </div>
            </div>
          </AnimatedCard>
        </div>
      </div>
    </section>
  );
};

export default AboutPreview;
