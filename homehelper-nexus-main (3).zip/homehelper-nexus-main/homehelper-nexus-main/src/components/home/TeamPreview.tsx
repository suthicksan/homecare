
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const teamMembers = [
  {
    name: "Jennifer Wilson",
    role: "CEO & Founder",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
  },
  {
    name: "Robert Garcia",
    role: "Operations Manager",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
  },
  {
    name: "Emily Thompson",
    role: "Customer Success Manager",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
  },
  {
    name: "Michael Lee",
    role: "Lead Technician",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
  }
];

const TeamPreview = () => {
  return (
    <section className="py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-6 md:px-8">
        <AnimatedCard>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              The dedicated professionals behind our exceptional service.
            </p>
          </div>
        </AnimatedCard>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <AnimatedCard key={index} delay={index * 100}>
              <Link to="/team" className="glass-card h-full rounded-xl overflow-hidden block transition-all duration-300 hover:shadow-lg">
                <div className="aspect-w-1 aspect-h-1 w-full">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4 text-center">
                  <h3 className="text-lg font-semibold mb-1">{member.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{member.role}</p>
                </div>
              </Link>
            </AnimatedCard>
          ))}
        </div>

        <AnimatedCard delay={500}>
          <div className="text-center mt-12">
            <Button asChild variant="outline">
              <Link to="/team">
                Meet the Full Team
                <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </Button>
          </div>
        </AnimatedCard>
      </div>
    </section>
  );
};

export default TeamPreview;
