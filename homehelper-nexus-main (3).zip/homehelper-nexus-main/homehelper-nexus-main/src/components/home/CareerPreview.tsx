
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const positions = [
  "Senior Home Service Technician",
  "Customer Success Specialist",
  "Service Operations Manager",
  "Field Service Coordinator"
];

const benefits = [
  {
    title: "Flexible Schedule",
    description: "Work-life balance is important to us. Enjoy flexible scheduling to fit your lifestyle."
  },
  {
    title: "Competitive Pay",
    description: "We offer industry-leading compensation packages with performance bonuses."
  },
  {
    title: "Growth Opportunities",
    description: "Continuous training and clear career advancement paths for all employees."
  },
  {
    title: "Health Benefits",
    description: "Comprehensive health, dental, and vision insurance for you and your family."
  }
];

const CareerPreview = () => {
  return (
    <section className="py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-6 md:px-8">
        <AnimatedCard>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Team</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Build your career with us and help deliver exceptional service to our customers.
            </p>
          </div>
        </AnimatedCard>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <AnimatedCard delay={100}>
            <div className="glass-card rounded-xl p-8">
              <h3 className="text-xl font-semibold mb-6">Current Openings</h3>
              <ul className="space-y-4 mb-8">
                {positions.map((position, index) => (
                  <li key={index} className="flex items-center">
                    <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                    <span>{position}</span>
                  </li>
                ))}
              </ul>
              <Button asChild>
                <Link to="/careers">
                  View All Positions
                </Link>
              </Button>
            </div>
          </AnimatedCard>

          <AnimatedCard delay={200}>
            <div>
              <h3 className="text-xl font-semibold mb-6">Why Work With Us</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {benefits.map((benefit, index) => (
                  <div key={index} className="glass-card rounded-xl p-6">
                    <h4 className="font-semibold mb-2">{benefit.title}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{benefit.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </AnimatedCard>
        </div>
      </div>
    </section>
  );
};

export default CareerPreview;
