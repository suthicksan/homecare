
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";

const pricingPlans = [
  {
    name: "Basic",
    price: "$49",
    description: "Perfect for a single service",
    features: [
      "One-time service",
      "Standard scheduling",
      "Email support",
      "90-day guarantee"
    ]
  },
  {
    name: "Premium",
    price: "$129",
    description: "Great for regular home maintenance",
    features: [
      "Monthly service",
      "Priority scheduling",
      "Phone and email support",
      "1-year guarantee",
      "10% discount on additional services"
    ],
    popular: true
  },
  {
    name: "Professional",
    price: "$299",
    description: "Complete home care solution",
    features: [
      "Quarterly service package",
      "24/7 emergency service",
      "Dedicated account manager",
      "2-year guarantee",
      "20% discount on additional services",
      "Annual home inspection"
    ]
  }
];

const PricingPreview = () => {
  return (
    <section className="py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6 md:px-8">
        <AnimatedCard>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Choose the plan that works best for your home service needs.
            </p>
          </div>
        </AnimatedCard>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <AnimatedCard key={index} delay={index * 100}>
              <div className={`glass-card h-full rounded-xl overflow-hidden ${plan.popular ? 'border-2 border-primary' : ''}`}>
                {plan.popular && (
                  <div className="bg-primary text-white text-center py-1 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    <span className="text-gray-500 dark:text-gray-400"> / package</span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">{plan.description}</p>
                  
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-gray-600 dark:text-gray-300 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button variant={plan.popular ? "default" : "outline"} className="w-full" asChild>
                    <Link to="/booking">Get Started</Link>
                  </Button>
                </div>
              </div>
            </AnimatedCard>
          ))}
        </div>

        <AnimatedCard delay={400}>
          <div className="text-center mt-12">
            <Link to="/pricing" className="text-primary hover:underline inline-flex items-center">
              View complete pricing details
              <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </AnimatedCard>
      </div>
    </section>
  );
};

export default PricingPreview;
