
import { AnimatedCard } from "@/components/ui/AnimatedCard";

const testimonials = [
  {
    id: 1,
    content: "The cleaning service was excellent! The team was thorough, professional, and left my home spotless. I've already booked them again for next month.",
    author: "Michael Johnson",
    role: "Homeowner",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 2,
    content: "I had an electrical issue that needed immediate attention. The electrician arrived within hours, quickly diagnosed the problem, and fixed it at a reasonable cost.",
    author: "Sarah Williams",
    role: "Apartment Resident",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80"
  },
  {
    id: 3,
    content: "The landscaping team transformed my backyard into a beautiful garden. They listened to my ideas and created exactly what I envisioned. Highly recommended!",
    author: "David Chen",
    role: "Property Owner",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80"
  }
];

const Testimonials = () => {
  return (
    <section className="py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-6 md:px-8">
        <AnimatedCard>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Don't just take our word for it. Hear from some of our satisfied customers.
            </p>
          </div>
        </AnimatedCard>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <AnimatedCard key={testimonial.id} delay={index * 100}>
              <div className="glass-card h-full rounded-xl p-6 relative">
                <div className="absolute -top-5 left-6 w-10 h-10 bg-primary text-white flex items-center justify-center rounded-full text-2xl">
                  "
                </div>
                <div className="pt-6">
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    "{testimonial.content}"
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                      <img src={testimonial.image} alt={testimonial.author} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="font-semibold">{testimonial.author}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              </div>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
