
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { HelpCircle, Clock, CreditCard, Shield } from "lucide-react";

const faqs = [
  {
    question: "How do I book a service?",
    answer: "You can book a service by navigating to our booking page, selecting the service you need, choosing a date and time that works for you, and providing your contact information.",
    icon: <Clock className="w-6 h-6 text-primary" />
  },
  {
    question: "What is your cancellation policy?",
    answer: "You can cancel or reschedule your appointment up to 24 hours before the scheduled time without any charges. Cancellations made less than 24 hours in advance may be subject to a cancellation fee.",
    icon: <CreditCard className="w-6 h-6 text-primary" />
  },
  {
    question: "Are your service providers vetted?",
    answer: "Yes, all our service providers undergo a thorough background check and skill assessment before joining our platform. We ensure they meet our high standards for professionalism and expertise.",
    icon: <Shield className="w-6 h-6 text-primary" />
  },
  {
    question: "What happens if I'm not satisfied with the service?",
    answer: "Your satisfaction is our priority. If you're not happy with the service provided, please contact us within 48 hours, and we'll work to resolve the issue, which may include scheduling a follow-up service at no additional cost.",
    icon: <HelpCircle className="w-6 h-6 text-primary" />
  }
];

const FAQ = () => {
  return (
    <section id="faq" className="py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6 md:px-8">
        <AnimatedCard>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Find answers to common questions about our services and how we work.
            </p>
          </div>
        </AnimatedCard>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <AnimatedCard key={index} delay={index * 100}>
              <div className="glass-card rounded-xl mb-6 overflow-hidden">
                <div className="p-6">
                  <div className="flex items-start mb-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                      {faq.icon}
                    </div>
                    <h3 className="text-xl font-semibold">{faq.question}</h3>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 pl-14">{faq.answer}</p>
                </div>
              </div>
            </AnimatedCard>
          ))}

          <AnimatedCard delay={400}>
            <div className="text-center mt-10">
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Don't see your question here? Visit our complete FAQ page for more information.
              </p>
              <Button asChild>
                <Link to="/faq">View All FAQs</Link>
              </Button>
            </div>
          </AnimatedCard>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
