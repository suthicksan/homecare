
import React, { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { useIntersectionObserver } from "@/lib/animations";

interface AnimatedCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  delay?: number;
  animationType?: "fade-up" | "fade-in" | "slide-in-right";
}

export function AnimatedCard({ 
  children, 
  delay = 0, 
  animationType = "fade-up", 
  className, 
  ...props 
}: AnimatedCardProps) {
  const [ref, isIntersecting] = useIntersectionObserver();
  const [hasAnimated, setHasAnimated] = useState(false);
  
  useEffect(() => {
    if (isIntersecting && !hasAnimated) {
      setHasAnimated(true);
    }
  }, [isIntersecting, hasAnimated]);

  const animationClass = hasAnimated ? 
    `animate-${animationType}` : 
    'opacity-0 translate-y-8';

  const style = {
    animationDelay: `${delay}ms`,
    animationFillMode: 'forwards' as const,
  };

  return (
    <div
      ref={ref}
      className={cn(
        "transition-all duration-700 ease-out will-change-transform",
        animationClass,
        className
      )}
      style={hasAnimated ? style : undefined}
      {...props}
    >
      {children}
    </div>
  );
}
