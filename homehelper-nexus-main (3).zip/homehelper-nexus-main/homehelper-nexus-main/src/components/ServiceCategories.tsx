
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { cn } from "@/lib/utils";

const serviceCategories = [
  {
    id: 1,
    name: "Home Cleaning",
    description: "Professional house cleaning services for a spotless home.",
    icon: "🧹",
    image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: 2,
    name: "Plumbing",
    description: "Expert plumbing repairs, installations, and maintenance.",
    icon: "🔧",
    image: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: 3,
    name: "Electrical",
    description: "Safe and reliable electrical services for your home.",
    icon: "⚡",
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: 4,
    name: "Landscaping",
    description: "Transform your outdoor space with our landscaping services.",
    icon: "🌿",
    image: "https://images.unsplash.com/photo-1558904541-efa843a96f01?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: 5,
    name: "Furniture Assembly",
    description: "Quick and efficient furniture assembly services.",
    icon: "🪑",
    image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: 6,
    name: "Painting",
    description: "Interior and exterior painting services for a fresh look.",
    icon: "🎨",
    image: "https://images.unsplash.com/photo-1571781565036-d3f759be73e4?q=80&w=600&auto=format&fit=crop",
  },
];

const ServiceCategories = () => {
  return (
    <section id="services" className="py-24 bg-gray-50 dark:bg-gray-900 overflow-hidden">
      <div className="container mx-auto px-6 md:px-8">
        <div className="text-center mb-16">
          <AnimatedCard>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Discover our wide range of professional home services tailored to meet your specific needs.
            </p>
          </AnimatedCard>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceCategories.map((service, index) => (
            <AnimatedCard 
              key={service.id} 
              delay={index * 100}
              className="h-full"
            >
              <div className="glass-card h-full rounded-xl overflow-hidden hover:shadow-md transition-all duration-300 hover:translate-y-[-4px]">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.name}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <span className="text-2xl">{service.icon}</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{service.name}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">{service.description}</p>
                  <div className="pt-4 border-t border-gray-100 dark:border-gray-800">
                    <a href="#booking" className="text-primary text-sm font-medium inline-flex items-center hover:underline">
                      Book now
                      <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServiceCategories;
