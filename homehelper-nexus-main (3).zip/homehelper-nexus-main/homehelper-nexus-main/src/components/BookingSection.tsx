
import { useState } from "react";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import ProgressSteps from "@/components/booking/ProgressSteps";
import ServiceSelectionStep from "@/components/booking/ServiceSelectionStep";
import LocationDateStep from "@/components/booking/LocationDateStep";
import ContactInfoStep from "@/components/booking/ContactInfoStep";
import TermsAndPolicy from "@/components/booking/TermsAndPolicy";
import { serviceOptions } from "@/components/booking/serviceOptions";

interface BookingSectionProps {
  onBookingComplete?: () => void;
}

const BookingSection = ({ onBookingComplete }: BookingSectionProps) => {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 3;

  const handleContinue = () => {
    setCurrentStep(prev => Math.min(prev + 1, totalSteps));
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = () => {
    // Handle form submission
    console.log("Booking submitted with service:", selectedService);
    // Call the onBookingComplete callback if provided
    if (onBookingComplete) {
      onBookingComplete();
    }
  };

  return (
    <section id="booking" className="py-24 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 overflow-hidden">
      <div className="container mx-auto px-6 md:px-8">
        <div className="text-center mb-16">
          <AnimatedCard>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Book a Service</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Schedule a service in just a few steps. Our verified professionals are ready to help.
            </p>
          </AnimatedCard>
        </div>

        <div className="max-w-3xl mx-auto">
          <AnimatedCard delay={100}>
            <div className="glass-card rounded-xl p-8 mb-8">
              <ProgressSteps currentStep={currentStep} totalSteps={totalSteps} />

              {currentStep === 1 && (
                <ServiceSelectionStep 
                  serviceOptions={serviceOptions}
                  selectedService={selectedService}
                  setSelectedService={setSelectedService}
                  onContinue={handleContinue}
                />
              )}

              {currentStep === 2 && (
                <LocationDateStep 
                  onBack={handleBack}
                  onContinue={handleContinue}
                />
              )}

              {currentStep === 3 && (
                <ContactInfoStep 
                  onBack={handleBack}
                  onSubmit={handleSubmit}
                />
              )}
            </div>
          </AnimatedCard>

          <AnimatedCard delay={200}>
            <TermsAndPolicy />
          </AnimatedCard>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;
