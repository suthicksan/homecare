
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";

const providers = [
  {
    id: 1,
    name: "Alex Johnson",
    title: "Professional Cleaner",
    rating: 4.9,
    reviews: 127,
    availability: "Available today",
    location: "San Francisco, CA",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
  },
  {
    id: 2,
    name: "Maria Rodriguez",
    title: "Plumbing Expert",
    rating: 4.8,
    reviews: 89,
    availability: "Available tomorrow",
    location: "New York, NY",
    image: "https://randomuser.me/api/portraits/women/47.jpg",
  },
  {
    id: 3,
    name: "David Chen",
    title: "Electrician",
    rating: 5.0,
    reviews: 64,
    availability: "Available today",
    location: "Chicago, IL",
    image: "https://randomuser.me/api/portraits/men/18.jpg",
  },
  {
    id: 4,
    name: "Sarah Miller",
    title: "Landscaping Professional",
    rating: 4.7,
    reviews: 52,
    availability: "Available in 2 days",
    location: "Austin, TX",
    image: "https://randomuser.me/api/portraits/women/63.jpg",
  },
];

const FeaturedProviders = () => {
  return (
    <section id="providers" className="py-24 overflow-hidden">
      <div className="container mx-auto px-6 md:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16">
          <AnimatedCard>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Providers</h2>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl">
                Our top-rated professionals ready to help with your home care needs.
              </p>
            </div>
          </AnimatedCard>
          
          <AnimatedCard delay={200}>
            <Button variant="ghost" className="mt-4 md:mt-0">
              View all providers
              <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Button>
          </AnimatedCard>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {providers.map((provider, index) => (
            <AnimatedCard 
              key={provider.id} 
              delay={index * 100}
              className="h-full"
            >
              <div className="glass-card h-full rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg group">
                <div className="aspect-w-3 aspect-h-2 w-full relative">
                  <img 
                    src={provider.image} 
                    alt={provider.name}
                    className="w-full h-full object-cover"
                  />
                  
                  <div className="absolute top-3 right-3 px-2 py-1 bg-white/90 dark:bg-black/90 rounded text-xs font-medium backdrop-blur-sm">
                    {provider.availability}
                  </div>
                </div>
                
                <div className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold">{provider.name}</h3>
                    <div className="flex items-center">
                      <span className="text-yellow-500 mr-1">★</span>
                      <span className="text-sm font-medium">{provider.rating}</span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{provider.title}</p>
                  
                  <div className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                    {provider.reviews} reviews • {provider.location}
                  </div>
                  
                  <Button size="sm" className="w-full group-hover:bg-primary/90 transition-colors">
                    Book Now
                  </Button>
                </div>
              </div>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProviders;
