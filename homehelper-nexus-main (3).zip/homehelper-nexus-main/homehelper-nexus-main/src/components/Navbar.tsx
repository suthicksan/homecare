
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Menu, X, User, Home, Phone, Info, Book, DollarSign, HelpCircle, Users, Briefcase } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4",
        isScrolled ? "bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm shadow-sm py-3" : "bg-transparent"
      )}
    >
      <div className="container mx-auto px-6 md:px-8 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <span className="text-xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-500">HomeHelp</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/services" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <Home className="w-4 h-4" />
            <span>Services</span>
          </Link>
          <Link to="/pricing" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <DollarSign className="w-4 h-4" />
            <span>Pricing</span>
          </Link>
          <Link to="/about" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <Info className="w-4 h-4" />
            <span>About</span>
          </Link>
          <Link to="/team" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <Users className="w-4 h-4" />
            <span>Team</span>
          </Link>
          <Link to="/careers" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <Briefcase className="w-4 h-4" />
            <span>Careers</span>
          </Link>
          <Link to="/faq" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4" />
            <span>FAQ</span>
          </Link>
          <Link to="/contact" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1.5">
            <Phone className="w-4 h-4" />
            <span>Contact</span>
          </Link>
        </div>

        <div className="hidden md:flex items-center space-x-4">
          {isAuthenticated ? (
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center space-x-2"
                onClick={() => navigate('/profile')}
              >
                <User size={18} />
                <span>Profile</span>
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                Sign Out
              </Button>
            </div>
          ) : (
            <>
              <Button variant="outline" size="sm" className="font-medium" asChild>
                <Link to="/login">Sign In</Link>
              </Button>
              <Button size="sm" className="font-medium" asChild>
                <Link to="/signup">Sign Up</Link>
              </Button>
            </>
          )}
          <Button size="sm" className="font-medium bg-green-600 hover:bg-green-700" asChild>
            <Link to="/booking">
              <Book className="w-4 h-4 mr-1" />
              Book Now
            </Link>
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center space-x-3">
          <Button size="sm" className="font-medium bg-green-600 hover:bg-green-700" asChild>
            <Link to="/booking">
              <Book className="w-4 h-4 mr-1" />
              Book
            </Link>
          </Button>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-gray-700 dark:text-gray-200 focus:outline-none"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md pt-20 transition-all duration-300 ease-in-out md:hidden",
          isMobileMenuOpen ? "opacity-100 translate-x-0" : "opacity-0 translate-x-full pointer-events-none"
        )}
      >
        <div className="container mx-auto px-6 flex flex-col space-y-6 py-6">
          <Link
            to="/services"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <Home className="w-5 h-5 mr-2" />
            Services
          </Link>
          <Link
            to="/pricing"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <DollarSign className="w-5 h-5 mr-2" />
            Pricing
          </Link>
          <Link
            to="/about"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <Info className="w-5 h-5 mr-2" />
            About
          </Link>
          <Link
            to="/team"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <Users className="w-5 h-5 mr-2" />
            Team
          </Link>
          <Link
            to="/careers"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <Briefcase className="w-5 h-5 mr-2" />
            Careers
          </Link>
          <Link
            to="/faq"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <HelpCircle className="w-5 h-5 mr-2" />
            FAQ
          </Link>
          <Link
            to="/contact"
            className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <Phone className="w-5 h-5 mr-2" />
            Contact
          </Link>
          
          {isAuthenticated ? (
            <>
              <Link
                to="/profile"
                className="text-lg font-medium px-2 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors flex items-center"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <User className="w-5 h-5 mr-2" />
                Profile
              </Link>
              <button
                onClick={() => {
                  handleLogout();
                  setIsMobileMenuOpen(false);
                }}
                className="text-lg font-medium px-2 py-3 text-left text-red-500 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors"
              >
                Sign Out
              </button>
            </>
          ) : (
            <div className="flex flex-col space-y-4 pt-4">
              <Button 
                variant="outline" 
                className="w-full justify-center font-medium"
                onClick={() => {
                  navigate('/login');
                  setIsMobileMenuOpen(false);
                }}
              >
                Sign In
              </Button>
              <Button 
                className="w-full justify-center font-medium"
                onClick={() => {
                  navigate('/signup');
                  setIsMobileMenuOpen(false);
                }}
              >
                Sign Up
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
