
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

const Hero = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative pt-32 pb-24 overflow-hidden">
      {/* Background gradient elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl opacity-60"></div>
        <div className="absolute bottom-1/3 left-1/4 w-64 h-64 bg-purple-400/20 rounded-full blur-3xl opacity-60"></div>
      </div>

      {/* Content */}
      <div className="container relative mx-auto px-6 md:px-8 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className={cn(
            "transition-all duration-1000 ease-out",
            isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )}>
            <span className="inline-block px-3 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full mb-6">
              Trusted by 10,000+ customers
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Expert home services, <br className="hidden md:block" />
              <span className="text-primary">delivered with care</span>
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-lg">
              Connect with verified professionals for all your home care needs. From cleaning to repairs, we ensure quality service every time.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="font-medium" asChild>
                <Link to="/booking">Book a Service</Link>
              </Button>
              <Button variant="outline" size="lg" className="font-medium" asChild>
                <Link to="/signup">Become a Provider</Link>
              </Button>
            </div>
            
            {/* Trust indicators */}
            <div className="mt-12 flex items-center space-x-6">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((_, index) => (
                  <div
                    key={index}
                    className="w-10 h-10 rounded-full border-2 border-white dark:border-gray-900 bg-gray-200 dark:bg-gray-700 overflow-hidden"
                  >
                    <img 
                      src={`https://randomuser.me/api/portraits/women/${index + 10}.jpg`}
                      alt={`Customer ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
              <div>
                <div className="text-sm font-medium">Trusted by</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">over 10,000 customers</div>
              </div>
            </div>
          </div>

          <div className={cn(
            "transition-all duration-1000 delay-300 ease-out",
            isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
          )}>
            <div className="relative">
              {/* Main image */}
              <div className="rounded-xl overflow-hidden shadow-2xl bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <div className="aspect-w-4 aspect-h-5 h-[500px] w-full relative">
                  <img 
                    src="https://images.unsplash.com/photo-1623280962049-2446e0dac30a?q=80&w=1200&auto=format&fit=crop"
                    alt="Professional home service" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -left-8 -bottom-6 glass-card p-3 rounded-lg shadow-lg animate-slide-in-right opacity-0" style={{ animationDelay: '600ms', animationFillMode: 'forwards' }}>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/women/23.jpg" 
                      alt="Sarah T."
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="text-sm font-medium">Sarah T.</div>
                    <div className="text-xs text-primary">Verified Professional</div>
                  </div>
                </div>
              </div>
              
              <div className="absolute -right-8 top-1/4 glass-card p-3 rounded-lg shadow-lg animate-slide-in-right opacity-0" style={{ animationDelay: '800ms', animationFillMode: 'forwards' }}>
                <div className="text-sm font-medium">4.9 <span className="text-yellow-500">★★★★★</span></div>
                <div className="text-xs text-gray-500 dark:text-gray-400">Average rating</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
