
import { Check } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { serviceOptions } from "@/components/booking/serviceOptions";

const pricingPlans = [
  {
    title: "Basic",
    price: 49,
    description: "Perfect for simple tasks and small spaces",
    features: [
      "2-hour service",
      "Single room coverage",
      "Standard equipment",
      "Email support",
      "48-hour response time"
    ]
  },
  {
    title: "Standard",
    price: 99,
    description: "Our most popular plan for regular service needs",
    features: [
      "4-hour service",
      "Up to 3 rooms coverage",
      "Premium equipment",
      "Priority email support",
      "24-hour response time",
      "30-day service guarantee"
    ],
    popular: true
  },
  {
    title: "Premium",
    price: 199,
    description: "Comprehensive coverage for your entire home",
    features: [
      "Full-day service",
      "Whole home coverage",
      "Professional-grade equipment",
      "Priority phone & email support",
      "Same-day response time",
      "90-day service guarantee",
      "Free follow-up inspection"
    ]
  }
];

const serviceRates = serviceOptions.map(service => {
  let baseRate;
  switch(service.id) {
    case "cleaning": baseRate = 35; break;
    case "plumbing": baseRate = 55; break;
    case "electrical": baseRate = 60; break;
    case "landscaping": baseRate = 45; break;
    case "assembly": baseRate = 40; break;
    case "painting": baseRate = 50; break;
    default: baseRate = 45;
  }
  return {
    ...service,
    baseRate
  };
});

const Pricing = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <AnimatedCard>
            <div className="text-center mb-16">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Transparent Pricing</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Choose the plan that fits your needs. All plans include our satisfaction guarantee and expert service providers.
              </p>
            </div>
          </AnimatedCard>

          {/* Pricing Plans */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {pricingPlans.map((plan, index) => (
              <AnimatedCard key={plan.title} delay={index * 100}>
                <div className={`glass-card rounded-xl p-8 h-full flex flex-col relative ${plan.popular ? 'border-2 border-primary shadow-lg' : ''}`}>
                  {plan.popular && (
                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-xs font-bold px-4 py-1 rounded-full">
                      Most Popular
                    </div>
                  )}
                  <h3 className="text-xl font-bold mb-2">{plan.title}</h3>
                  <div className="mb-4">
                    <span className="text-3xl font-bold">${plan.price}</span>
                    <span className="text-gray-500 dark:text-gray-400">/service</span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-6">{plan.description}</p>
                  <div className="space-y-3 mb-8 flex-grow">
                    {plan.features.map((feature, i) => (
                      <div key={i} className="flex items-start">
                        <Check className="w-5 h-5 text-green-500 mr-2 shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full" asChild>
                    <a href="/booking">Get Started</a>
                  </Button>
                </div>
              </AnimatedCard>
            ))}
          </div>

          {/* Service Rates */}
          <AnimatedCard delay={400}>
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Service Hourly Rates</h2>
              <div className="overflow-x-auto">
                <table className="w-full glass-card rounded-xl overflow-hidden">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-gray-800">
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Service Type</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Base Rate (per hour)</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Weekend Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {serviceRates.map((service) => (
                      <tr key={service.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{service.label}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">${service.baseRate}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">${Math.round(service.baseRate * 1.25)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </AnimatedCard>

          <AnimatedCard delay={500}>
            <div className="glass-card p-8 rounded-xl mt-12 text-center">
              <h2 className="text-2xl font-bold mb-4">Need a Custom Quote?</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
                For larger projects or specialized services, we offer custom quotes tailored to your specific needs.
              </p>
              <Button asChild>
                <a href="/contact">Contact Us</a>
              </Button>
            </div>
          </AnimatedCard>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Pricing;
