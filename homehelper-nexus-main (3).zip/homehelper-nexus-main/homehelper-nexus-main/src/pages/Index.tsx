
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { CalendarClock, Info, Users, MessageSquare, CreditCard, HelpCircle, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import ServiceCategories from "@/components/ServiceCategories";
import FeaturedProviders from "@/components/FeaturedProviders";
import BookingSection from "@/components/BookingSection";
import FAQ from "@/components/home/FAQ";
import Testimonials from "@/components/home/Testimonials";
import PricingPreview from "@/components/home/PricingPreview";
import TeamPreview from "@/components/home/TeamPreview";
import ContactPreview from "@/components/home/ContactPreview";
import CareerPreview from "@/components/home/CareerPreview";
import AboutPreview from "@/components/home/AboutPreview";
import Footer from "@/components/Footer";

const Index = () => {
  useEffect(() => {
    // Apply smooth scrolling for anchor links
    document.documentElement.classList.add('smooth-scroll');
    
    return () => {
      document.documentElement.classList.remove('smooth-scroll');
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main>
        <Hero />
        <ServiceCategories />
        <FeaturedProviders />
        
        {/* Quick links section */}
        <section className="py-16 bg-gray-50 dark:bg-gray-900">
          <div className="container mx-auto px-6 md:px-8">
            <AnimatedCard>
              <div className="text-center mb-10">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Explore Our Platform</h2>
                <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                  Discover all the features our platform has to offer for your home service needs.
                </p>
              </div>
            </AnimatedCard>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <AnimatedCard delay={100}>
                <Link to="/booking" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <CalendarClock className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Book a Service</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Schedule your next service appointment quickly and easily.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={150}>
                <Link to="/about" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <Info className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">About Us</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Learn more about our company and our mission to serve you better.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={200}>
                <Link to="/team" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Our Team</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Meet the professionals who make our service exceptional.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={250}>
                <Link to="/contact" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Contact Us</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Get in touch with our customer support team for any questions.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={300}>
                <Link to="/pricing" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <CreditCard className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Pricing</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">View our transparent pricing for all our services.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={350}>
                <Link to="/faq" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <HelpCircle className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">FAQ</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Find answers to frequently asked questions about our services.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={400}>
                <Link to="/careers" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <Briefcase className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Careers</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Join our team of dedicated professionals and grow with us.</p>
                </Link>
              </AnimatedCard>

              <AnimatedCard delay={450}>
                <Link to="/services" className="glass-card p-6 rounded-xl block transition-all hover:shadow-md hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <span className="text-2xl text-primary">🛠️</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">All Services</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Browse our complete catalog of professional home services.</p>
                </Link>
              </AnimatedCard>
            </div>
          </div>
        </section>

        <AboutPreview />
        <PricingPreview />
        <TeamPreview />
        <BookingSection />
        <FAQ />
        <Testimonials />
        <ContactPreview />
        <CareerPreview />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
