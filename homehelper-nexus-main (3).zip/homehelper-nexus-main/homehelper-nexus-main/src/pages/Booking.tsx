
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Calendar, Clock, MapPin, CheckCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BookingSection from "@/components/BookingSection";
import { Button } from "@/components/ui/button";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { toast } from "@/components/ui/use-toast";

const Booking = () => {
  const [bookingComplete, setBookingComplete] = useState(false);
  const navigate = useNavigate();

  const handleBookingSuccess = () => {
    setBookingComplete(true);
    toast({
      title: "Booking Submitted!",
      description: "We'll contact you shortly to confirm your appointment.",
      variant: "default",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            {bookingComplete ? (
              <AnimatedCard className="glass-card p-8 rounded-xl">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h1 className="text-2xl md:text-3xl font-bold">Booking Complete!</h1>
                  <p className="text-gray-600 dark:text-gray-300 max-w-md mx-auto">
                    Thank you for booking with us. We'll be in touch shortly to confirm your appointment details.
                  </p>
                  <div className="pt-6">
                    <Button onClick={() => navigate("/")}>
                      Return to Home
                    </Button>
                  </div>
                </div>
              </AnimatedCard>
            ) : (
              <>
                <AnimatedCard>
                  <h1 className="text-3xl md:text-4xl font-bold mb-4 text-center">Book a Service</h1>
                  <p className="text-gray-600 dark:text-gray-300 text-center mb-8">
                    Complete the form below to schedule your service appointment
                  </p>
                </AnimatedCard>

                <div className="mb-12 grid grid-cols-1 md:grid-cols-3 gap-6">
                  <AnimatedCard delay={100}>
                    <div className="glass-card p-6 rounded-xl text-center">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Calendar className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="font-medium mb-2">Choose a Date</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Select your preferred service date</p>
                    </div>
                  </AnimatedCard>

                  <AnimatedCard delay={200}>
                    <div className="glass-card p-6 rounded-xl text-center">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Clock className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="font-medium mb-2">Pick a Time</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Choose a time that works for you</p>
                    </div>
                  </AnimatedCard>

                  <AnimatedCard delay={300}>
                    <div className="glass-card p-6 rounded-xl text-center">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <MapPin className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="font-medium mb-2">Provide Location</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Tell us where you need the service</p>
                    </div>
                  </AnimatedCard>
                </div>

                <AnimatedCard delay={400}>
                  <BookingSection onBookingComplete={handleBookingSuccess} />
                </AnimatedCard>
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Booking;
