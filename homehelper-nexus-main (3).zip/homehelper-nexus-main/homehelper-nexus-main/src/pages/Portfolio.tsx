
import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const categories = ["All", "Cleaning", "Plumbing", "Electrical", "Landscaping"];

const portfolioItems = [
  {
    id: 1,
    title: "Modern Kitchen Renovation",
    category: "Plumbing",
    image: "https://images.unsplash.com/photo-1556911220-bff31c812dba?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Complete kitchen plumbing overhaul with new fixtures and appliance connections."
  },
  {
    id: 2,
    title: "Office Space Deep Clean",
    category: "Cleaning",
    image: "https://images.unsplash.com/photo-1628177142898-93e36e4e3a50?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Commercial office deep cleaning including carpets, windows, and air ducts."
  },
  {
    id: 3,
    title: "Home Security Lighting",
    category: "Electrical",
    image: "https://images.unsplash.com/photo-1558959356-2b5f328a4b75?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Outdoor security lighting installation with motion sensors and timers."
  },
  {
    id: 4,
    title: "Backyard Transformation",
    category: "Landscaping",
    image: "https://images.unsplash.com/photo-1555680202-c86f0e12f086?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Complete backyard redesign with new plantings, lighting, and irrigation."
  },
  {
    id: 5,
    title: "Post-Construction Cleanup",
    category: "Cleaning",
    image: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Thorough cleaning after home renovation, including debris removal and surface cleaning."
  },
  {
    id: 6,
    title: "Smart Home Installation",
    category: "Electrical",
    image: "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Installation of smart home devices, including thermostats, lighting, and security systems."
  },
  {
    id: 7,
    title: "Bathroom Plumbing Renovation",
    category: "Plumbing",
    image: "https://images.unsplash.com/photo-1584622650111-993a426bcf0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Complete bathroom plumbing update with new fixtures and water-saving features."
  },
  {
    id: 8,
    title: "Seasonal Garden Maintenance",
    category: "Landscaping",
    image: "https://images.unsplash.com/photo-1590247813693-5541d1c609fd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Regular garden maintenance services, including pruning, planting, and lawn care."
  }
];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  
  const filteredItems = activeCategory === "All"
    ? portfolioItems
    : portfolioItems.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <AnimatedCard>
            <div className="text-center mb-16">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Our Work Portfolio</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Browse through our recent projects and see the quality of our services firsthand.
              </p>
            </div>
          </AnimatedCard>

          <AnimatedCard delay={100}>
            <Tabs defaultValue="All" className="mb-12">
              <div className="flex justify-center mb-8">
                <TabsList>
                  {categories.map(category => (
                    <TabsTrigger 
                      key={category} 
                      value={category}
                      onClick={() => setActiveCategory(category)}
                    >
                      {category}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>

              <TabsContent value={activeCategory} className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredItems.map((item) => (
                    <div key={item.id} className="glass-card rounded-xl overflow-hidden transition-all hover:shadow-lg">
                      <div className="aspect-w-16 aspect-h-9">
                        <img 
                          src={item.image} 
                          alt={item.title} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-6">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-lg font-semibold">{item.title}</h3>
                          <span className="text-xs font-medium bg-primary/10 text-primary px-2 py-1 rounded">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                          {item.description}
                        </p>
                        <Button size="sm" variant="outline">View Details</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </AnimatedCard>

          <AnimatedCard delay={200}>
            <div className="glass-card p-8 rounded-xl text-center mt-12">
              <h2 className="text-2xl font-bold mb-4">Need a Service Like These?</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
                Our team of professionals is ready to help with your next project. Contact us today for a free consultation.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button asChild>
                  <a href="/booking">Book a Service</a>
                </Button>
                <Button asChild variant="outline">
                  <a href="/contact">Contact Us</a>
                </Button>
              </div>
            </div>
          </AnimatedCard>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Portfolio;
