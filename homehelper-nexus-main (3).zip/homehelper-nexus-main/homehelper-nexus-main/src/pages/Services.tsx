
import { useState } from "react";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

// Sample services data
const services = [
  {
    id: 1,
    name: "Home Cleaning",
    description: "Professional house cleaning services for a spotless home. Our expert cleaners use premium products and techniques to ensure your home is clean and healthy.",
    image: "/placeholder.svg",
    category: "cleaning",
    price: "From $80",
    rating: 4.9,
    reviewCount: 124
  },
  {
    id: 2,
    name: "Plumbing",
    description: "Expert plumbing services for repairs, installations, and maintenance. Our licensed plumbers can handle everything from leaky faucets to complete bathroom renovations.",
    image: "/placeholder.svg",
    category: "repairs",
    price: "From $95",
    rating: 4.8,
    reviewCount: 87
  },
  {
    id: 3,
    name: "Electrical",
    description: "Safe and reliable electrical services for your home. Our certified electricians can install fixtures, repair wiring, upgrade panels, and more.",
    image: "/placeholder.svg",
    category: "repairs",
    price: "From $100",
    rating: 4.7,
    reviewCount: 92
  },
  {
    id: 4,
    name: "Landscaping",
    description: "Transform your outdoor space with our professional landscaping services. We offer garden design, lawn care, tree services, and hardscape installations.",
    image: "/placeholder.svg",
    category: "outdoor",
    price: "From $120",
    rating: 4.9,
    reviewCount: 76
  },
  {
    id: 5,
    name: "Furniture Assembly",
    description: "Fast and reliable furniture assembly services. Our skilled technicians can assemble any type of furniture, from IKEA items to complex pieces.",
    image: "/placeholder.svg",
    category: "handyman",
    price: "From $65",
    rating: 4.8,
    reviewCount: 103
  },
  {
    id: 6,
    name: "Painting",
    description: "Professional interior and exterior painting services. Our experienced painters deliver flawless results with attention to detail and premium materials.",
    image: "/placeholder.svg",
    category: "renovation",
    price: "From $150",
    rating: 4.9,
    reviewCount: 68
  },
  {
    id: 7,
    name: "Carpet Cleaning",
    description: "Deep carpet cleaning services that remove stains, allergens, and odors. We use eco-friendly products and professional equipment for best results.",
    image: "/placeholder.svg",
    category: "cleaning",
    price: "From $75",
    rating: 4.7,
    reviewCount: 81
  },
  {
    id: 8,
    name: "HVAC Services",
    description: "Comprehensive heating, ventilation, and air conditioning services. Our technicians provide installations, repairs, and maintenance for all HVAC systems.",
    image: "/placeholder.svg",
    category: "repairs",
    price: "From $120",
    rating: 4.8,
    reviewCount: 94
  }
];

// All service categories
const categories = [
  { value: "all", label: "All Services" },
  { value: "cleaning", label: "Cleaning" },
  { value: "repairs", label: "Repairs & Maintenance" },
  { value: "outdoor", label: "Outdoor & Gardening" },
  { value: "handyman", label: "Handyman" },
  { value: "renovation", label: "Renovation" }
];

const Services = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredServices = services.filter(service => {
    const matchesCategory = selectedCategory === "all" || service.category === selectedCategory;
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         service.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <section className="py-24 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-6 md:px-8">
            <AnimatedCard>
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
                <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                  Browse our wide range of professional home services, all delivered by vetted experts who care about quality.
                </p>
              </div>
            </AnimatedCard>

            <AnimatedCard delay={100}>
              <div className="mb-12 flex flex-col md:flex-row gap-6 justify-between">
                <div className="w-full md:w-1/3">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search services..."
                    className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary"
                  />
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <button
                      key={category.value}
                      className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                        selectedCategory === category.value
                          ? "bg-primary text-white"
                          : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700"
                      }`}
                      onClick={() => setSelectedCategory(category.value)}
                    >
                      {category.label}
                    </button>
                  ))}
                </div>
              </div>
            </AnimatedCard>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredServices.map((service, index) => (
                <AnimatedCard key={service.id} delay={200 + (index * 50)} className="h-full">
                  <div className="glass-card h-full rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg">
                    <div className="aspect-w-16 aspect-h-9 w-full">
                      <div className="w-full h-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
                    </div>
                    
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-xl font-semibold">{service.name}</h3>
                        <span className="inline-block bg-primary/10 text-primary px-2 py-1 rounded-lg text-sm">
                          {service.price}
                        </span>
                      </div>
                      
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-2">
                        {service.description}
                      </p>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <span className="text-yellow-500 mr-1">★</span>
                          <span className="text-sm font-medium">{service.rating}</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">
                            ({service.reviewCount} reviews)
                          </span>
                        </div>
                        <span className="text-xs py-1 px-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                          {categories.find(c => c.value === service.category)?.label}
                        </span>
                      </div>
                      
                      <div className="flex gap-3">
                        <Button asChild className="flex-1">
                          <Link to={`/service/${service.id}`}>
                            View Details
                          </Link>
                        </Button>
                        <Button variant="outline" className="flex-1">
                          Book Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </AnimatedCard>
              ))}
            </div>
            
            {filteredServices.length === 0 && (
              <AnimatedCard delay={200}>
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600"></div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">No services found</h3>
                  <p className="text-gray-600 dark:text-gray-300 max-w-md mx-auto">
                    We couldn't find any services matching your search criteria. Please try a different search or category.
                  </p>
                  <Button onClick={() => {setSelectedCategory("all"); setSearchQuery("");}} className="mt-4">
                    View All Services
                  </Button>
                </div>
              </AnimatedCard>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Services;
