
import { Mail, Linkedin, Twitter } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";

const teamMembers = [
  {
    name: "Sarah Johnson",
    role: "CEO & Founder",
    bio: "Sarah founded HomeHelp with a vision to transform the home service industry. With over 15 years of experience in service management, she leads our team with passion and dedication.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
    social: {
      email: "sarah@homehelp.com",
      linkedin: "#",
      twitter: "#"
    }
  },
  {
    name: "Michael Rodriguez",
    role: "Operations Director",
    bio: "Michael oversees all service operations, ensuring every customer receives exceptional service. His background in logistics and customer service excellence drives our operational success.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
    social: {
      email: "michael@homehelp.com",
      linkedin: "#",
      twitter: "#"
    }
  },
  {
    name: "Jennifer Chen",
    role: "Customer Experience Manager",
    bio: "Jennifer is dedicated to creating seamless, positive experiences for our customers. She works closely with our service providers to maintain our high standards of quality and satisfaction.",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
    social: {
      email: "jennifer@homehelp.com",
      linkedin: "#",
      twitter: "#"
    }
  },
  {
    name: "David Wilson",
    role: "Lead Technician",
    bio: "With over 20 years in home repair and maintenance, David leads our technical team. He specializes in complex repairs and training our new service providers to meet our exacting standards.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
    social: {
      email: "david@homehelp.com",
      linkedin: "#",
      twitter: "#"
    }
  },
  {
    name: "Emma Thompson",
    role: "Marketing Director",
    bio: "Emma brings creativity and strategic thinking to our marketing efforts. She's passionate about sharing the HomeHelp story and connecting our services with homeowners who need them.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
    social: {
      email: "emma@homehelp.com",
      linkedin: "#",
      twitter: "#"
    }
  },
  {
    name: "James Park",
    role: "Quality Assurance Specialist",
    bio: "James ensures that all our services meet the highest standards of quality. He conducts regular reviews and implements continuous improvement processes across all service categories.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80",
    social: {
      email: "james@homehelp.com",
      linkedin: "#",
      twitter: "#"
    }
  }
];

const Team = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <AnimatedCard>
            <div className="text-center mb-16">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Meet Our Team</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Our talented team of professionals is committed to delivering exceptional home services. Get to know the people behind HomeHelp's success.
              </p>
            </div>
          </AnimatedCard>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {teamMembers.map((member, index) => (
              <AnimatedCard key={member.name} delay={index * 100}>
                <div className="glass-card rounded-xl overflow-hidden h-full flex flex-col">
                  <div className="h-64 relative overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover object-center transition-transform hover:scale-105 duration-500"
                    />
                  </div>
                  <div className="p-6 flex-grow">
                    <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                    <p className="text-primary mb-4 text-sm font-medium">{member.role}</p>
                    <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">{member.bio}</p>
                    <div className="flex space-x-3">
                      <a
                        href={`mailto:${member.social.email}`}
                        className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
                        aria-label={`Email ${member.name}`}
                      >
                        <Mail className="w-4 h-4" />
                      </a>
                      <a
                        href={member.social.linkedin}
                        className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-[#0077B5] hover:text-white transition-colors"
                        aria-label={`LinkedIn profile for ${member.name}`}
                      >
                        <Linkedin className="w-4 h-4" />
                      </a>
                      <a
                        href={member.social.twitter}
                        className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-[#1DA1F2] hover:text-white transition-colors"
                        aria-label={`Twitter profile for ${member.name}`}
                      >
                        <Twitter className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                </div>
              </AnimatedCard>
            ))}
          </div>

          <AnimatedCard delay={700}>
            <div className="glass-card p-8 rounded-xl text-center">
              <h2 className="text-2xl font-bold mb-4">Join Our Team</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
                We're always looking for talented professionals to join our growing team. If you're passionate about providing excellent service and want to be part of a supportive, innovative company, we'd love to hear from you.
              </p>
              <Button asChild size="lg">
                <a href="/careers">View Open Positions</a>
              </Button>
            </div>
          </AnimatedCard>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Team;
