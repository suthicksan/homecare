
import { Briefcase, Users, Heart, TrendingUp, CheckCircle, MapPin, ChevronRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";

const benefits = [
  {
    icon: <Users className="w-6 h-6 text-primary" />,
    title: "Collaborative Environment",
    description: "Work with a supportive team that values your input and ideas"
  },
  {
    icon: <TrendingUp className="w-6 h-6 text-primary" />,
    title: "Career Growth",
    description: "Clear paths for advancement and professional development opportunities"
  },
  {
    icon: <Heart className="w-6 h-6 text-primary" />,
    title: "Comprehensive Benefits",
    description: "Health insurance, retirement plans, and generous PTO"
  },
  {
    icon: <Briefcase className="w-6 h-6 text-primary" />,
    title: "Work-Life Balance",
    description: "Flexible scheduling options and respect for your personal time"
  }
];

const openPositions = [
  {
    title: "Senior Service Technician",
    location: "New York, NY",
    type: "Full-time",
    description: "We're seeking an experienced technician to lead service calls and mentor junior team members. Expertise in multiple service areas required.",
    id: "tech-001"
  },
  {
    title: "Customer Service Representative",
    location: "Remote",
    type: "Full-time",
    description: "Help our customers book services and resolve inquiries. Strong communication skills and problem-solving abilities needed.",
    id: "csr-002"
  },
  {
    title: "Regional Service Manager",
    location: "Chicago, IL",
    type: "Full-time",
    description: "Oversee service operations in the Midwest region, ensuring quality standards and customer satisfaction targets are met.",
    id: "mgr-003"
  },
  {
    title: "Marketing Specialist",
    location: "Austin, TX",
    type: "Full-time",
    description: "Develop and implement marketing strategies to grow our customer base in new markets.",
    id: "mkt-004"
  },
  {
    title: "Weekend Service Technician",
    location: "Los Angeles, CA",
    type: "Part-time",
    description: "Provide quality service to our customers during weekend hours. Training provided for the right candidate.",
    id: "tech-005"
  }
];

const Careers = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <AnimatedCard>
            <div className="text-center mb-16">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Careers at HomeHelp</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Join our team of passionate professionals dedicated to improving homes and simplifying lives. Discover opportunities to grow your career while making a difference.
              </p>
            </div>
          </AnimatedCard>

          {/* Why Join Us Section */}
          <div className="mb-20">
            <AnimatedCard delay={100}>
              <h2 className="text-2xl font-bold mb-8 text-center">Why Join HomeHelp?</h2>
            </AnimatedCard>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {benefits.map((benefit, index) => (
                <AnimatedCard key={benefit.title} delay={200 + index * 100}>
                  <div className="glass-card rounded-xl p-6 h-full">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      {benefit.icon}
                    </div>
                    <h3 className="font-semibold mb-2">{benefit.title}</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">{benefit.description}</p>
                  </div>
                </AnimatedCard>
              ))}
            </div>
          </div>

          {/* Company Culture */}
          <AnimatedCard delay={600}>
            <div className="glass-card rounded-xl overflow-hidden mb-20">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <h2 className="text-2xl font-bold mb-4">Our Company Culture</h2>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    At HomeHelp, we foster an environment of innovation, inclusion, and excellence. We value diversity of thought and background, believing that our differences make us stronger.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                      <p className="text-sm">Continuous learning and professional development</p>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                      <p className="text-sm">Recognition of individual and team achievements</p>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                      <p className="text-sm">Commitment to community service and sustainability</p>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                      <p className="text-sm">Work-life balance and employee wellbeing</p>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-100 dark:bg-gray-800 h-64 md:h-auto">
                  <img 
                    src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                    alt="Team collaboration" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </AnimatedCard>

          {/* Open Positions */}
          <AnimatedCard delay={700}>
            <h2 className="text-2xl font-bold mb-8 text-center">Open Positions</h2>
          </AnimatedCard>

          <div className="space-y-4 mb-12">
            {openPositions.map((position, index) => (
              <AnimatedCard key={position.id} delay={800 + index * 100}>
                <div className="glass-card rounded-xl p-6 hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div>
                      <h3 className="font-bold text-lg mb-2">{position.title}</h3>
                      <div className="flex flex-wrap items-center text-sm text-gray-600 dark:text-gray-400 mb-4">
                        <div className="flex items-center mr-4">
                          <MapPin className="w-4 h-4 mr-1" />
                          {position.location}
                        </div>
                        <div className="flex items-center">
                          <Briefcase className="w-4 h-4 mr-1" />
                          {position.type}
                        </div>
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 md:mb-0">{position.description}</p>
                    </div>
                    <Button className="shrink-0" size="sm" asChild>
                      <a href={`/careers/${position.id}`} className="inline-flex items-center">
                        View Details
                        <ChevronRight className="ml-1 w-4 h-4" />
                      </a>
                    </Button>
                  </div>
                </div>
              </AnimatedCard>
            ))}
          </div>

          {/* Apply Section */}
          <AnimatedCard delay={1300}>
            <div className="glass-card p-8 rounded-xl text-center">
              <h2 className="text-2xl font-bold mb-4">Don't See a Perfect Fit?</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
                We're always interested in connecting with talented individuals. Send us your resume, and we'll keep you in mind for future opportunities.
              </p>
              <Button asChild size="lg">
                <a href="mailto:careers@homehelp.com">
                  Send Your Resume
                </a>
              </Button>
            </div>
          </AnimatedCard>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Careers;
