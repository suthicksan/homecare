
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { useNavigate } from "react-router-dom";
import { 
  Users, 
  Settings, 
  BarChart3, 
  ShieldCheck, 
  FileText, 
  Bell
} from "lucide-react";

// Mock data for admin dashboard
const mockStats = {
  totalUsers: 1254,
  totalProviders: 348,
  activeBookings: 126,
  completedServices: 3487,
  revenue: "$54,982",
  satisfactionRate: "94.7%"
};

// Mock user data for user management
const mockUsers = [
  { id: "1", name: "John Doe", email: "user@example.com", role: "user", status: "active" },
  { id: "2", name: "Jane Smith", email: "provider@example.com", role: "provider", status: "active" },
  { id: "3", name: "Alice Johnson", email: "alice@example.com", role: "user", status: "inactive" },
  { id: "4", name: "Bob Williams", email: "bob@example.com", role: "provider", status: "pending" },
];

const Admin = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("dashboard");
  
  useEffect(() => {
    // Redirect if not admin
    if (user?.role !== 'admin') {
      navigate('/');
    }
  }, [user, navigate]);

  if (user?.role !== 'admin') {
    return null; // Don't render anything while redirecting
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-20">
      <div className="container mx-auto px-4 py-8">
        <AnimatedCard>
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Welcome back, Administrator. Manage your HomeHelp platform here.
          </p>
        </AnimatedCard>

        <div className="flex flex-col md:flex-row gap-6 mt-6">
          {/* Sidebar / Navigation */}
          <AnimatedCard delay={100} className="md:w-64 w-full">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <nav className="space-y-2">
                <Button 
                  variant={activeTab === "dashboard" ? "default" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("dashboard")}
                >
                  <BarChart3 className="mr-2 h-5 w-5" />
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === "users" ? "default" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("users")}
                >
                  <Users className="mr-2 h-5 w-5" />
                  User Management
                </Button>
                <Button 
                  variant={activeTab === "services" ? "default" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("services")}
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Service Management
                </Button>
                <Button 
                  variant={activeTab === "notifications" ? "default" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("notifications")}
                >
                  <Bell className="mr-2 h-5 w-5" />
                  Notifications
                </Button>
                <Button 
                  variant={activeTab === "settings" ? "default" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("settings")}
                >
                  <Settings className="mr-2 h-5 w-5" />
                  Settings
                </Button>
                <Button 
                  variant={activeTab === "security" ? "default" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("security")}
                >
                  <ShieldCheck className="mr-2 h-5 w-5" />
                  Security
                </Button>
              </nav>
            </div>
          </AnimatedCard>

          {/* Main Content */}
          <AnimatedCard delay={200} className="flex-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              {activeTab === "dashboard" && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Platform Overview</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                      <div className="text-blue-500 font-medium">Total Users</div>
                      <div className="text-2xl font-bold">{mockStats.totalUsers}</div>
                    </div>
                    <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                      <div className="text-green-500 font-medium">Service Providers</div>
                      <div className="text-2xl font-bold">{mockStats.totalProviders}</div>
                    </div>
                    <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg">
                      <div className="text-amber-500 font-medium">Active Bookings</div>
                      <div className="text-2xl font-bold">{mockStats.activeBookings}</div>
                    </div>
                    <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-lg">
                      <div className="text-indigo-500 font-medium">Completed Services</div>
                      <div className="text-2xl font-bold">{mockStats.completedServices}</div>
                    </div>
                    <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
                      <div className="text-purple-500 font-medium">Total Revenue</div>
                      <div className="text-2xl font-bold">{mockStats.revenue}</div>
                    </div>
                    <div className="bg-teal-50 dark:bg-teal-900/20 p-4 rounded-lg">
                      <div className="text-teal-500 font-medium">Satisfaction Rate</div>
                      <div className="text-2xl font-bold">{mockStats.satisfactionRate}</div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "users" && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">User Management</h2>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-100 dark:bg-gray-700">
                          <th className="px-4 py-2 text-left">Name</th>
                          <th className="px-4 py-2 text-left">Email</th>
                          <th className="px-4 py-2 text-left">Role</th>
                          <th className="px-4 py-2 text-left">Status</th>
                          <th className="px-4 py-2 text-left">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockUsers.map((user) => (
                          <tr key={user.id} className="border-b dark:border-gray-700">
                            <td className="px-4 py-3">{user.name}</td>
                            <td className="px-4 py-3">{user.email}</td>
                            <td className="px-4 py-3 capitalize">{user.role}</td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                user.status === 'active' 
                                  ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                                  : user.status === 'inactive'
                                  ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                                  : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                              }`}>
                                {user.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button size="sm" variant="outline">Edit</Button>
                                <Button size="sm" variant="outline" className="text-red-500 border-red-200 hover:bg-red-50">
                                  Disable
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === "services" && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Service Management</h2>
                  <p className="text-gray-500 dark:text-gray-400">
                    Manage service categories, pricing, and availability here.
                  </p>
                </div>
              )}

              {activeTab === "notifications" && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Notification Center</h2>
                  <p className="text-gray-500 dark:text-gray-400">
                    Manage and send notifications to users and service providers.
                  </p>
                </div>
              )}

              {activeTab === "settings" && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Platform Settings</h2>
                  <p className="text-gray-500 dark:text-gray-400">
                    Configure platform settings, features, and integrations.
                  </p>
                </div>
              )}

              {activeTab === "security" && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Security Settings</h2>
                  <p className="text-gray-500 dark:text-gray-400">
                    Manage security settings, user permissions, and access controls.
                  </p>
                </div>
              )}
            </div>
          </AnimatedCard>
        </div>
      </div>
    </div>
  );
};

export default Admin;
