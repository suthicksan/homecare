
import { useState } from "react";
import { ChevronDown, HelpCircle, Clock, CreditCard, Shield, Award } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { cn } from "@/lib/utils";

const faqCategories = [
  {
    title: "Booking & Scheduling",
    icon: <Clock className="w-5 h-5" />,
    questions: [
      {
        question: "How far in advance should I book a service?",
        answer: "We recommend booking at least 48 hours in advance for standard services. For urgent requests, we offer same-day service based on availability, though a rush fee may apply."
      },
      {
        question: "Can I reschedule my appointment?",
        answer: "Yes! You can reschedule your appointment up to 24 hours before your scheduled time without any penalty. Changes made with less notice may incur a rescheduling fee."
      },
      {
        question: "What is your cancellation policy?",
        answer: "Cancellations made at least 24 hours before your scheduled appointment are free of charge. Late cancellations (less than 24 hours notice) may be subject to a cancellation fee of 50% of the service cost."
      }
    ]
  },
  {
    title: "Services & Pricing",
    icon: <CreditCard className="w-5 h-5" />,
    questions: [
      {
        question: "How are your services priced?",
        answer: "Our services are priced based on the type of service, size of the job, and time required. We offer transparent pricing with no hidden fees. You can view our general pricing on our Pricing page, or request a custom quote for larger projects."
      },
      {
        question: "Do I need to provide any equipment or supplies?",
        answer: "No, our professionals come fully equipped with all necessary tools and supplies needed to complete the job. If specialized equipment is required, we'll discuss this with you beforehand."
      },
      {
        question: "Are there any services you don't offer?",
        answer: "While we cover a wide range of home services, there are some specialized services we may not provide, such as major construction or certain types of hazardous materials handling. Please contact us if you're unsure about a specific service."
      }
    ]
  },
  {
    title: "Service Guarantees",
    icon: <Shield className="w-5 h-5" />,
    questions: [
      {
        question: "What if I'm not satisfied with the service?",
        answer: "Your satisfaction is our priority. If you're not completely satisfied with our work, please let us know within 48 hours and we'll return to address any concerns at no additional cost."
      },
      {
        question: "Are your service providers insured?",
        answer: "Yes, all our service providers are fully insured and have undergone thorough background checks. We cover any accidental damages that might occur during service."
      },
      {
        question: "Do you offer any warranties on completed work?",
        answer: "Yes, we stand behind our work. Depending on the service, we offer warranties ranging from 30 to 90 days. Specific warranty information is provided when your service is completed."
      }
    ]
  },
  {
    title: "Service Providers",
    icon: <Award className="w-5 h-5" />,
    questions: [
      {
        question: "How do you select your service providers?",
        answer: "Our service providers undergo a rigorous selection process including background checks, skill verification, and professional reference checks. We only work with experienced professionals who meet our high standards."
      },
      {
        question: "Can I request a specific service provider?",
        answer: "Yes! If you've worked with one of our service providers before and would like to request them again, you can indicate this when booking. We'll do our best to accommodate your preference based on availability."
      },
      {
        question: "Are your service providers employees or contractors?",
        answer: "Our service providers are a mix of employees and vetted independent contractors. Regardless of their employment status, all providers follow our strict quality standards and service protocols."
      }
    ]
  }
];

const FAQ = () => {
  const [openCategory, setOpenCategory] = useState(0);
  const [openQuestions, setOpenQuestions] = useState<Record<number, Record<number, boolean>>>({});

  const toggleQuestion = (categoryIndex: number, questionIndex: number) => {
    setOpenQuestions(prev => ({
      ...prev,
      [categoryIndex]: {
        ...(prev[categoryIndex] || {}),
        [questionIndex]: !(prev[categoryIndex]?.[questionIndex] || false)
      }
    }));
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <AnimatedCard>
            <div className="text-center mb-16">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Find answers to common questions about our services, booking process, and more. If you don't see your question here, feel free to contact us.
              </p>
            </div>
          </AnimatedCard>

          <div className="max-w-3xl mx-auto">
            <div className="glass-card rounded-xl overflow-hidden mb-8">
              <div className="grid grid-cols-1 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-gray-200 dark:divide-gray-700">
                {faqCategories.map((category, index) => (
                  <div
                    key={index}
                    className={cn(
                      "p-4 text-center cursor-pointer transition-colors",
                      openCategory === index
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-gray-50 dark:hover:bg-gray-800/50"
                    )}
                    onClick={() => setOpenCategory(index)}
                  >
                    <div className="flex flex-col items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                        {category.icon}
                      </div>
                      <span className="text-sm font-medium">{category.title}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <AnimatedCard delay={100}>
              <div className="glass-card rounded-xl p-6 md:p-8">
                <div className="flex items-center mb-6">
                  <HelpCircle className="w-6 h-6 text-primary mr-2" />
                  <h2 className="text-xl font-bold">{faqCategories[openCategory].title}</h2>
                </div>

                <div className="space-y-4">
                  {faqCategories[openCategory].questions.map((faq, qIndex) => (
                    <div key={qIndex} className="border-b border-gray-200 dark:border-gray-700 pb-4 last:border-0 last:pb-0">
                      <button
                        className="flex justify-between items-center w-full text-left py-2 focus:outline-none"
                        onClick={() => toggleQuestion(openCategory, qIndex)}
                      >
                        <span className="font-medium">{faq.question}</span>
                        <ChevronDown
                          className={cn(
                            "w-5 h-5 transition-transform",
                            openQuestions[openCategory]?.[qIndex] ? "transform rotate-180" : ""
                          )}
                        />
                      </button>
                      <div
                        className={cn(
                          "mt-2 text-gray-600 dark:text-gray-400 text-sm overflow-hidden transition-all",
                          openQuestions[openCategory]?.[qIndex] ? "max-h-96" : "max-h-0"
                        )}
                      >
                        <p className="pb-2">{faq.answer}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </AnimatedCard>

            <AnimatedCard delay={200}>
              <div className="text-center mt-12">
                <h3 className="text-xl font-semibold mb-4">Still have questions?</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6">
                  We're here to help! Contact our customer support team and we'll get back to you promptly.
                </p>
                <a
                  href="/contact"
                  className="inline-flex items-center justify-center gap-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors"
                >
                  Contact Support
                </a>
              </div>
            </AnimatedCard>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default FAQ;
