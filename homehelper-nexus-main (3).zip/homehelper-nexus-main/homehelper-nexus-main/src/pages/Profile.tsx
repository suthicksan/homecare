
import { useState, useEffect } from "react";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Profile = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState("profile");
  const [profileData, setProfileData] = useState({
    fullName: user?.name || "",
    email: user?.email || "",
    phone: "",
    location: "",
    bio: ""
  });
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Mock data for bookings and preferences
  const bookings = [
    { id: 1, service: "Home Cleaning", date: "2023-10-15", status: "completed", provider: "Sarah Miller" },
    { id: 2, service: "Plumbing", date: "2023-11-02", status: "scheduled", provider: "Michael Brown" },
    { id: 3, service: "Landscaping", date: "2023-11-10", status: "pending", provider: "David Martinez" }
  ];

  const notifications = [
    { enabled: true, type: "email", label: "Email Notifications" },
    { enabled: false, type: "sms", label: "SMS Notifications" },
    { enabled: true, type: "app", label: "App Notifications" }
  ];

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setIsEditing(false);
      toast.success("Profile updated successfully!");
    }, 1000);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="flex-grow py-24">
        <div className="container mx-auto px-6 md:px-8">
          <AnimatedCard>
            <div className="glass-card rounded-xl overflow-hidden">
              <div className="flex flex-col md:flex-row">
                {/* Sidebar */}
                <div className="w-full md:w-64 bg-gray-50 dark:bg-gray-800 p-6 md:border-r border-gray-200 dark:border-gray-700">
                  <div className="flex flex-col items-center mb-8">
                    <div className="w-24 h-24 rounded-full overflow-hidden mb-4">
                      <div className="w-full h-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
                    </div>
                    <h2 className="text-xl font-bold">{user?.name}</h2>
                    <p className="text-gray-500 dark:text-gray-400 text-sm">{user?.role}</p>
                  </div>
                  
                  <nav className="space-y-1">
                    {[
                      { id: "profile", label: "Profile" },
                      { id: "bookings", label: "My Bookings" },
                      { id: "settings", label: "Settings" }
                    ].map((item) => (
                      <button
                        key={item.id}
                        className={`w-full px-4 py-2 text-left rounded-lg transition-colors ${
                          activeTab === item.id 
                            ? "bg-primary text-white" 
                            : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                        }`}
                        onClick={() => setActiveTab(item.id)}
                      >
                        {item.label}
                      </button>
                    ))}
                    
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/20"
                      onClick={handleLogout}
                    >
                      Logout
                    </Button>
                  </nav>
                </div>
                
                {/* Main content */}
                <div className="flex-grow p-6">
                  {/* Profile Tab */}
                  {activeTab === "profile" && (
                    <div>
                      <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold">My Profile</h2>
                        {!isEditing && (
                          <Button variant="outline" onClick={() => setIsEditing(true)}>
                            Edit Profile
                          </Button>
                        )}
                      </div>
                      
                      {isEditing ? (
                        <form onSubmit={handleProfileSubmit}>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                              <label className="block text-sm font-medium mb-1">Full Name</label>
                              <input
                                type="text"
                                name="fullName"
                                value={profileData.fullName}
                                onChange={handleProfileChange}
                                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary/50 focus:border-primary"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Email</label>
                              <input
                                type="email"
                                name="email"
                                value={profileData.email}
                                onChange={handleProfileChange}
                                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary/50 focus:border-primary"
                                disabled
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Phone</label>
                              <input
                                type="tel"
                                name="phone"
                                value={profileData.phone}
                                onChange={handleProfileChange}
                                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary/50 focus:border-primary"
                                placeholder="Your phone number"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Location</label>
                              <input
                                type="text"
                                name="location"
                                value={profileData.location}
                                onChange={handleProfileChange}
                                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary/50 focus:border-primary"
                                placeholder="City, State"
                              />
                            </div>
                          </div>
                          
                          <div className="mb-6">
                            <label className="block text-sm font-medium mb-1">Bio</label>
                            <textarea
                              name="bio"
                              value={profileData.bio}
                              onChange={handleProfileChange}
                              rows={4}
                              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-primary/50 focus:border-primary"
                              placeholder="Tell us about yourself"
                            ></textarea>
                          </div>
                          
                          <div className="flex gap-3">
                            <Button type="submit" disabled={isLoading}>
                              {isLoading ? (
                                <div className="flex items-center">
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                  Saving...
                                </div>
                              ) : (
                                "Save Changes"
                              )}
                            </Button>
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => setIsEditing(false)}
                              disabled={isLoading}
                            >
                              Cancel
                            </Button>
                          </div>
                        </form>
                      ) : (
                        <div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Full Name</h3>
                              <p className="text-gray-900 dark:text-white">{profileData.fullName || "Not set"}</p>
                            </div>
                            <div>
                              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Email</h3>
                              <p className="text-gray-900 dark:text-white">{profileData.email}</p>
                            </div>
                            <div>
                              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Phone</h3>
                              <p className="text-gray-900 dark:text-white">{profileData.phone || "Not set"}</p>
                            </div>
                            <div>
                              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Location</h3>
                              <p className="text-gray-900 dark:text-white">{profileData.location || "Not set"}</p>
                            </div>
                          </div>
                          
                          <div>
                            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Bio</h3>
                            <p className="text-gray-900 dark:text-white whitespace-pre-line">
                              {profileData.bio || "No bio information added yet."}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Bookings Tab */}
                  {activeTab === "bookings" && (
                    <div>
                      <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold">My Bookings</h2>
                        <Button variant="outline">Book New Service</Button>
                      </div>
                      
                      {bookings.length > 0 ? (
                        <div className="space-y-4">
                          {bookings.map((booking) => (
                            <div 
                              key={booking.id} 
                              className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700"
                            >
                              <div className="flex justify-between items-center mb-2">
                                <h3 className="font-bold text-lg">{booking.service}</h3>
                                <span className={`px-2 py-1 rounded-full text-xs ${
                                  booking.status === "completed" 
                                    ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                                    : booking.status === "scheduled"
                                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
                                    : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                                }`}>
                                  {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                                </span>
                              </div>
                              <div className="grid grid-cols-2 gap-2 mb-3">
                                <div>
                                  <p className="text-sm text-gray-500 dark:text-gray-400">Date</p>
                                  <p>{new Date(booking.date).toLocaleDateString()}</p>
                                </div>
                                <div>
                                  <p className="text-sm text-gray-500 dark:text-gray-400">Provider</p>
                                  <p>{booking.provider}</p>
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button size="sm" variant="outline">View Details</Button>
                                {booking.status !== "completed" && (
                                  <Button size="sm" variant="outline" className="text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/20">
                                    Cancel
                                  </Button>
                                )}
                                {booking.status === "completed" && (
                                  <Button size="sm" variant="outline">
                                    Leave Review
                                  </Button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full mx-auto mb-4 flex items-center justify-center">
                            <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600"></div>
                          </div>
                          <h3 className="text-xl font-semibold mb-2">No bookings yet</h3>
                          <p className="text-gray-600 dark:text-gray-300 max-w-md mx-auto mb-4">
                            You haven't booked any services yet. Browse our services and make your first booking.
                          </p>
                          <Button>Book a Service</Button>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Settings Tab */}
                  {activeTab === "settings" && (
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Settings</h2>
                      
                      <div className="mb-8">
                        <h3 className="text-lg font-semibold mb-4">Notification Preferences</h3>
                        <div className="space-y-4">
                          {notifications.map((notification, index) => (
                            <div 
                              key={index}
                              className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700"
                            >
                              <span>{notification.label}</span>
                              <div className="relative inline-block w-12 h-6 rounded-full bg-gray-200 dark:bg-gray-700">
                                <input 
                                  type="checkbox" 
                                  className="sr-only" 
                                  defaultChecked={notification.enabled}
                                />
                                <span className={`absolute left-1 top-1 w-4 h-4 rounded-full transition-all duration-200 ${
                                  notification.enabled ? "bg-primary translate-x-6" : "bg-white dark:bg-gray-400"
                                }`}></span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="mb-8">
                        <h3 className="text-lg font-semibold mb-4">Account Security</h3>
                        <div className="space-y-4">
                          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                            <h4 className="font-medium mb-2">Change Password</h4>
                            <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">
                              Regularly updating your password helps keep your account secure.
                            </p>
                            <Button variant="outline" size="sm">Change Password</Button>
                          </div>
                          
                          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                            <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
                            <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">
                              Add an extra layer of security to your account.
                            </p>
                            <Button variant="outline" size="sm">Enable 2FA</Button>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-red-500">Danger Zone</h3>
                        <div className="bg-red-50 dark:bg-red-900/10 rounded-lg p-4 border border-red-200 dark:border-red-900/20">
                          <h4 className="font-medium text-red-600 dark:text-red-400 mb-2">Delete Account</h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">
                            Once you delete your account, there is no going back. Please be certain.
                          </p>
                          <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/20">
                            Delete Account
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </AnimatedCard>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Profile;
