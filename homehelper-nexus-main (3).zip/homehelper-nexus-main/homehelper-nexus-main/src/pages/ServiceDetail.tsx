
import { useEffect, useState } from "react";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { useParams, Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

// Mock service details
const servicesData = [
  {
    id: "1",
    name: "Home Cleaning",
    description: "Professional house cleaning services for a spotless home. Our expert cleaners use premium products and techniques to ensure your home is clean and healthy.",
    longDescription: "Our comprehensive home cleaning service covers all areas of your home, from dusting and vacuuming to detailed kitchen and bathroom cleaning. We use eco-friendly products that are tough on dirt but gentle on your family and pets. Whether you need a one-time deep clean or regular maintenance, our trained professionals deliver consistent, high-quality results.",
    image: "/placeholder.svg",
    gallery: ["/placeholder.svg", "/placeholder.svg", "/placeholder.svg", "/placeholder.svg"],
    price: "From $80",
    priceDetails: [
      { name: "Standard Cleaning (1-2 hours)", price: "$80" },
      { name: "Deep Cleaning (3-4 hours)", price: "$160" },
      { name: "Move-in/Move-out Cleaning", price: "$200" }
    ],
    rating: 4.9,
    reviewCount: 124,
    benefits: [
      "Trained and background-checked cleaners",
      "Eco-friendly cleaning products",
      "Flexible scheduling options",
      "100% satisfaction guarantee",
      "Insured and bonded services"
    ],
    faqs: [
      {
        question: "How often should I schedule a cleaning service?",
        answer: "We recommend weekly or bi-weekly cleaning to maintain a consistently clean home. For homes with pets or children, weekly cleaning may be more appropriate."
      },
      {
        question: "What's included in your standard cleaning package?",
        answer: "Our standard cleaning includes dusting, vacuuming, mopping, bathroom cleaning, kitchen cleaning, and tidying up. Deep cleaning includes additional services like inside appliance cleaning, baseboard detailing, and more."
      },
      {
        question: "Do I need to provide cleaning supplies?",
        answer: "No, our cleaners bring all necessary cleaning supplies and equipment. If you have specific products you prefer, just let us know in advance."
      }
    ],
    providers: [
      { id: "1", name: "Sarah Miller", rating: 5.0, reviews: 42, image: "/placeholder.svg" },
      { id: "2", name: "John Davis", rating: 4.9, reviews: 38, image: "/placeholder.svg" },
      { id: "3", name: "Emma Johnson", rating: 4.8, reviews: 29, image: "/placeholder.svg" }
    ]
  },
  {
    id: "2",
    name: "Plumbing",
    description: "Expert plumbing services for repairs, installations, and maintenance. Our licensed plumbers can handle everything from leaky faucets to complete bathroom renovations.",
    longDescription: "Our professional plumbing service covers a wide range of needs, from emergency repairs to planned installations and routine maintenance. Our team of licensed plumbers has the expertise to handle any plumbing issue quickly and efficiently, minimizing disruption to your home. We use quality materials and provide transparent pricing with no hidden fees.",
    image: "/placeholder.svg",
    gallery: ["/placeholder.svg", "/placeholder.svg", "/placeholder.svg", "/placeholder.svg"],
    price: "From $95",
    priceDetails: [
      { name: "Service Call (1 hour)", price: "$95" },
      { name: "Fixture Installation", price: "From $150" },
      { name: "Drain Cleaning", price: "$120" },
      { name: "Pipe Repair", price: "From $200" }
    ],
    rating: 4.8,
    reviewCount: 87,
    benefits: [
      "Licensed and insured plumbers",
      "Available for emergencies 24/7",
      "Upfront, transparent pricing",
      "90-day workmanship warranty",
      "Clean and respectful service"
    ],
    faqs: [
      {
        question: "How quickly can you respond to plumbing emergencies?",
        answer: "We offer 24/7 emergency service and typically can have a plumber at your home within 1-2 hours for urgent issues like burst pipes or severe leaks."
      },
      {
        question: "Do you provide free estimates?",
        answer: "Yes, we provide free estimates for planned work. Emergency service calls do have a diagnostic fee, which is waived if you proceed with the recommended repairs."
      },
      {
        question: "Are your plumbers licensed and insured?",
        answer: "Yes, all our plumbers are fully licensed, bonded, and insured. We also perform background checks on all employees for your safety and peace of mind."
      }
    ],
    providers: [
      { id: "4", name: "Michael Brown", rating: 4.9, reviews: 56, image: "/placeholder.svg" },
      { id: "5", name: "Robert Wilson", rating: 4.8, reviews: 43, image: "/placeholder.svg" },
      { id: "6", name: "David Martinez", rating: 4.7, reviews: 31, image: "/placeholder.svg" }
    ]
  }
];

const ServiceDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [service, setService] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedImage, setSelectedImage] = useState("");

  useEffect(() => {
    // Simulate API fetch delay
    const timer = setTimeout(() => {
      const foundService = servicesData.find(s => s.id === id);
      setService(foundService || null);
      if (foundService) {
        setSelectedImage(foundService.image);
      }
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center py-24">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center py-24">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">Service Not Found</h1>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              We couldn't find the service you're looking for.
            </p>
            <Button asChild>
              <Link to="/services">Browse All Services</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <section className="py-24 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-6 md:px-8">
            <div className="flex flex-col lg:flex-row gap-12">
              <div className="lg:w-3/5">
                <AnimatedCard>
                  <div className="rounded-xl overflow-hidden mb-4">
                    <div className="aspect-w-16 aspect-h-9 w-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
                  </div>
                </AnimatedCard>
                
                <AnimatedCard delay={100}>
                  <div className="grid grid-cols-4 gap-2 mb-8">
                    {service.gallery.map((img: string, index: number) => (
                      <div 
                        key={index}
                        className={`rounded-lg overflow-hidden cursor-pointer border-2 ${
                          selectedImage === img ? 'border-primary' : 'border-transparent'
                        }`}
                        onClick={() => setSelectedImage(img)}
                      >
                        <div className="aspect-w-16 aspect-h-9 w-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
                      </div>
                    ))}
                  </div>
                </AnimatedCard>
                
                <AnimatedCard delay={200}>
                  <div className="mb-8">
                    <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6">
                      {["overview", "pricing", "providers", "faq"].map((tab) => (
                        <button
                          key={tab}
                          className={`px-4 py-3 font-medium text-sm transition-colors ${
                            activeTab === tab 
                              ? "text-primary border-b-2 border-primary" 
                              : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
                          }`}
                          onClick={() => setActiveTab(tab)}
                        >
                          {tab.charAt(0).toUpperCase() + tab.slice(1)}
                        </button>
                      ))}
                    </div>
                    
                    {activeTab === "overview" && (
                      <div>
                        <h2 className="text-3xl font-bold mb-4">{service.name}</h2>
                        <div className="flex items-center mb-6">
                          <span className="text-yellow-500 mr-1">★</span>
                          <span className="font-medium">{service.rating}</span>
                          <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">
                            ({service.reviewCount} reviews)
                          </span>
                        </div>
                        <div className="prose dark:prose-invert max-w-none mb-8">
                          <p>{service.longDescription}</p>
                        </div>
                        
                        <h3 className="text-xl font-bold mb-4">Service Benefits</h3>
                        <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8">
                          {service.benefits.map((benefit: string, index: number) => (
                            <li key={index} className="flex items-center">
                              <div className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-2">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M20 6L9 17L4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                                </svg>
                              </div>
                              <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {activeTab === "pricing" && (
                      <div>
                        <h2 className="text-3xl font-bold mb-4">Pricing Details</h2>
                        <p className="text-gray-600 dark:text-gray-300 mb-6">
                          We offer transparent pricing with no hidden fees. The final price may vary based on your specific requirements and home size.
                        </p>
                        
                        <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6 mb-8">
                          <h3 className="text-xl font-bold mb-4">Price Options</h3>
                          <div className="space-y-4">
                            {service.priceDetails.map((option: any, index: number) => (
                              <div key={index} className="flex justify-between items-center pb-2 border-b border-gray-200 dark:border-gray-700">
                                <span className="font-medium">{option.name}</span>
                                <span className="text-primary font-bold">{option.price}</span>
                              </div>
                            ))}
                          </div>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                            * Prices may vary based on the size and condition of your home.
                          </p>
                        </div>
                        
                        <div className="bg-primary/5 rounded-xl p-6">
                          <h3 className="text-xl font-bold mb-2">Need a custom quote?</h3>
                          <p className="text-gray-600 dark:text-gray-300 mb-4">
                            We can provide a personalized quote based on your specific needs.
                          </p>
                          <Button>Request Custom Quote</Button>
                        </div>
                      </div>
                    )}
                    
                    {activeTab === "providers" && (
                      <div>
                        <h2 className="text-3xl font-bold mb-4">Available Providers</h2>
                        <p className="text-gray-600 dark:text-gray-300 mb-6">
                          All our service providers are thoroughly vetted, background-checked, and trained to deliver exceptional service.
                        </p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {service.providers.map((provider: any) => (
                            <div key={provider.id} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6 flex items-center">
                              <div className="w-16 h-16 rounded-full overflow-hidden mr-4">
                                <div className="w-full h-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
                              </div>
                              <div>
                                <h3 className="font-bold text-lg">{provider.name}</h3>
                                <div className="flex items-center mt-1">
                                  <span className="text-yellow-500 mr-1">★</span>
                                  <span className="text-sm">{provider.rating}</span>
                                  <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">
                                    ({provider.reviews} reviews)
                                  </span>
                                </div>
                                <Button variant="outline" size="sm" className="mt-2">
                                  View Profile
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {activeTab === "faq" && (
                      <div>
                        <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
                        <div className="space-y-6">
                          {service.faqs.map((faq: any, index: number) => (
                            <div key={index} className="border-b border-gray-200 dark:border-gray-700 pb-6">
                              <h3 className="text-xl font-medium mb-2">{faq.question}</h3>
                              <p className="text-gray-600 dark:text-gray-300">{faq.answer}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </AnimatedCard>
              </div>
              
              <div className="lg:w-2/5">
                <AnimatedCard delay={300}>
                  <div className="glass-card rounded-xl p-6 mb-6 sticky top-24">
                    <h2 className="text-2xl font-bold mb-4">Book This Service</h2>
                    <div className="bg-primary/5 rounded-lg p-4 mb-6 flex justify-between items-center">
                      <span className="font-medium">Starting from</span>
                      <span className="text-xl font-bold text-primary">{service.price}</span>
                    </div>
                    
                    <div className="space-y-4 mb-6">
                      <div>
                        <label className="block text-sm font-medium mb-1">Service Date</label>
                        <input 
                          type="date" 
                          className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">Service Type</label>
                        <select 
                          className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary"
                        >
                          {service.priceDetails.map((option: any, index: number) => (
                            <option key={index} value={option.name}>{option.name} - {option.price}</option>
                          ))}
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">Your Address</label>
                        <input 
                          type="text" 
                          placeholder="Enter your address"
                          className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">Special Instructions</label>
                        <textarea 
                          placeholder="Any special requests or instructions"
                          rows={3}
                          className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary"
                        ></textarea>
                      </div>
                    </div>
                    
                    <Button className="w-full">Book Now</Button>
                    
                    <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
                      By booking, you agree to our <a href="#" className="text-primary hover:underline">Terms of Service</a>
                    </div>
                  </div>
                </AnimatedCard>
                
                <AnimatedCard delay={400}>
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6">
                    <h3 className="text-lg font-bold mb-4">Need Help?</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      Our customer support team is available to answer any questions.
                    </p>
                    <div className="flex gap-3">
                      <Button variant="outline" className="flex-1">
                        Chat Now
                      </Button>
                      <Button variant="outline" className="flex-1">
                        Call Us
                      </Button>
                    </div>
                  </div>
                </AnimatedCard>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ServiceDetail;
