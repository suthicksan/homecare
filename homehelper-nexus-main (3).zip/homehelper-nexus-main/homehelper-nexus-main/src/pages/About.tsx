
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <section className="py-24 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-6 md:px-8">
            <AnimatedCard>
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl font-bold mb-6">About HomeHelp</h1>
                <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                  We connect qualified professionals with homeowners looking for reliable services.
                </p>
              </div>
            </AnimatedCard>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
              <AnimatedCard delay={100}>
                <div className="rounded-xl overflow-hidden">
                  <div className="aspect-w-16 aspect-h-9 bg-gray-200 dark:bg-gray-700 image-loading"></div>
                </div>
              </AnimatedCard>

              <AnimatedCard delay={200}>
                <div>
                  <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    HomeHelp was founded with a clear mission: to transform how home services are delivered by creating a platform that values quality, reliability, and transparency. We believe everyone deserves access to trusted professionals who can help maintain and improve their homes.
                  </p>
                  <p className="text-gray-600 dark:text-gray-300">
                    We're committed to empowering service providers with the tools they need to grow their businesses while giving homeowners peace of mind with every service booking.
                  </p>
                </div>
              </AnimatedCard>
            </div>

            <AnimatedCard delay={300}>
              <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8 mb-20">
                <h2 className="text-3xl font-bold mb-8 text-center">Our Values</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600"></div>
                    </div>
                    <h3 className="text-xl font-semibold mb-3">Quality</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      We maintain high standards for our service providers through rigorous vetting and continuous feedback.
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600"></div>
                    </div>
                    <h3 className="text-xl font-semibold mb-3">Trust</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      We build trust through transparency, secure transactions, and verified professional profiles.
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600"></div>
                    </div>
                    <h3 className="text-xl font-semibold mb-3">Community</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      We foster a community where homeowners and service providers can build lasting relationships.
                    </p>
                  </div>
                </div>
              </div>
            </AnimatedCard>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
              <AnimatedCard delay={400}>
                <div>
                  <h2 className="text-3xl font-bold mb-6">Our Story</h2>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    HomeHelp was born out of personal frustration with the fragmented and unreliable home service market. After experiencing countless no-shows, poor quality work, and lack of transparency, our founders decided to create a better solution.
                  </p>
                  <p className="text-gray-600 dark:text-gray-300">
                    Since our launch in 2023, we've grown to serve thousands of homeowners across the country, connecting them with skilled professionals who take pride in their work and deliver exceptional results.
                  </p>
                </div>
              </AnimatedCard>

              <AnimatedCard delay={500}>
                <div className="rounded-xl overflow-hidden">
                  <div className="aspect-w-16 aspect-h-9 bg-gray-200 dark:bg-gray-700 image-loading"></div>
                </div>
              </AnimatedCard>
            </div>

            <AnimatedCard delay={600}>
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-6">Our Team</h2>
                <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                  Meet the dedicated individuals working behind the scenes to make HomeHelp the leading platform for home services.
                </p>
              </div>
            </AnimatedCard>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
              {[1, 2, 3, 4].map((_, index) => (
                <AnimatedCard key={index} delay={700 + (index * 100)}>
                  <div className="text-center">
                    <div className="w-32 h-32 rounded-full overflow-hidden mx-auto mb-4">
                      <div className="w-full h-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
                    </div>
                    <h3 className="text-xl font-semibold mb-1">Team Member {index + 1}</h3>
                    <p className="text-gray-500 dark:text-gray-400 mb-3">Position Title</p>
                    <p className="text-gray-600 dark:text-gray-300 text-sm">
                      Brief description about the team member and their contribution to HomeHelp.
                    </p>
                  </div>
                </AnimatedCard>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default About;
