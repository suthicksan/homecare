
import { useState } from "react";
import { Calendar, User, Tag, Search } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const blogPosts = [
  {
    id: 1,
    title: "10 Home Maintenance Tasks You Shouldn't Ignore",
    excerpt: "Regular home maintenance helps prevent costly repairs. Here are ten tasks homeowners should never skip...",
    image: "https://images.unsplash.com/photo-1584622650111-993a426bcf0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    date: "May 15, 2023",
    author: "Jessica Miller",
    tags: ["Maintenance", "Home Care", "DIY"]
  },
  {
    id: 2,
    title: "Energy-Saving Tips for Every Season",
    excerpt: "Learn how to reduce your energy bills year-round with these practical tips for every season...",
    image: "https://images.unsplash.com/photo-1532601224476-15c79f2f7a51?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    date: "June 22, 2023",
    author: "David Thompson",
    tags: ["Energy Saving", "Sustainability", "Home Tips"]
  },
  {
    id: 3,
    title: "How to Choose the Right Service Provider for Your Home",
    excerpt: "Finding reliable professionals can be challenging. Here's our guide to selecting the best service providers...",
    image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    date: "July 8, 2023",
    author: "Sarah Johnson",
    tags: ["Hiring Tips", "Service Providers", "Home Services"]
  },
  {
    id: 4,
    title: "Spring Cleaning Checklist: Room by Room Guide",
    excerpt: "Get your home spotless with our comprehensive spring cleaning guide that tackles every room in your house...",
    image: "https://images.unsplash.com/photo-1584722065776-3ddb908bd4b9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    date: "March 12, 2023",
    author: "Michael Roberts",
    tags: ["Cleaning", "Spring Cleaning", "Organization"]
  },
  {
    id: 5,
    title: "Smart Home Devices That Are Actually Worth It",
    excerpt: "Navigate the world of smart home technology with our expert recommendations on devices that truly improve your life...",
    image: "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    date: "August 30, 2023",
    author: "Ryan Peters",
    tags: ["Smart Home", "Technology", "Home Automation"]
  },
  {
    id: 6,
    title: "Preparing Your Home for Winter: A Complete Guide",
    excerpt: "Protect your home from winter damage with these essential preparation tips before the cold weather arrives...",
    image: "https://images.unsplash.com/photo-1604537466608-109fa2f16c3b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    date: "October 5, 2023",
    author: "Emily Wilson",
    tags: ["Winter Prep", "Home Maintenance", "Seasonal"]
  }
];

const Blog = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTag, setSelectedTag] = useState("");

  const allTags = Array.from(
    new Set(blogPosts.flatMap(post => post.tags))
  ).sort();

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = searchTerm === "" || 
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTag = selectedTag === "" || 
      post.tags.includes(selectedTag);
    
    return matchesSearch && matchesTag;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <AnimatedCard>
            <div className="text-center mb-16">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Our Blog</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Explore our articles for helpful tips, industry insights, and home maintenance advice.
              </p>
            </div>
          </AnimatedCard>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-12">
            <div className="lg:col-span-1">
              <AnimatedCard delay={100}>
                <div className="glass-card rounded-xl p-6 sticky top-24">
                  <div className="mb-6">
                    <h3 className="font-medium mb-3">Search Articles</h3>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        type="text"
                        placeholder="Search..."
                        className="pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">Filter by Tag</h3>
                    <div className="flex flex-wrap gap-2">
                      <Badge 
                        className={`cursor-pointer ${selectedTag === "" ? "bg-primary" : "bg-primary/20 hover:bg-primary/30 text-primary dark:text-primary-foreground"}`}
                        onClick={() => setSelectedTag("")}
                      >
                        All
                      </Badge>
                      {allTags.map(tag => (
                        <Badge 
                          key={tag}
                          className={`cursor-pointer ${selectedTag === tag ? "bg-primary" : "bg-primary/20 hover:bg-primary/30 text-primary dark:text-primary-foreground"}`}
                          onClick={() => setSelectedTag(tag)}
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </AnimatedCard>
            </div>

            <div className="lg:col-span-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredPosts.length > 0 ? (
                  filteredPosts.map((post, index) => (
                    <AnimatedCard key={post.id} delay={150 + index * 50}>
                      <div className="glass-card rounded-xl overflow-hidden h-full flex flex-col transition-all hover:shadow-lg">
                        <div className="aspect-w-16 aspect-h-9">
                          <img 
                            src={post.image} 
                            alt={post.title} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="p-6 flex-grow flex flex-col">
                          <h2 className="text-xl font-semibold mb-2">{post.title}</h2>
                          <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 flex-grow">{post.excerpt}</p>
                          
                          <div className="flex flex-wrap gap-2 mb-4">
                            {post.tags.map(tag => (
                              <Badge 
                                key={tag} 
                                variant="outline" 
                                className="bg-primary/5 text-primary"
                              >
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                            <div className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1" />
                              {post.date}
                            </div>
                            <div className="flex items-center">
                              <User className="w-4 h-4 mr-1" />
                              {post.author}
                            </div>
                          </div>
                          
                          <Button className="mt-4" size="sm">
                            Read More
                          </Button>
                        </div>
                      </div>
                    </AnimatedCard>
                  ))
                ) : (
                  <div className="col-span-full text-center py-12">
                    <p className="text-gray-500 dark:text-gray-400">No articles found matching your criteria.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <AnimatedCard delay={400}>
            <div className="glass-card p-8 rounded-xl text-center mt-8 bg-primary/5">
              <h2 className="text-2xl font-bold mb-4">Subscribe to Our Newsletter</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
                Get the latest articles, tips, and home service news delivered directly to your inbox.
              </p>
              <div className="flex max-w-md mx-auto">
                <Input type="email" placeholder="Your email address" className="rounded-r-none" />
                <Button className="rounded-l-none">Subscribe</Button>
              </div>
            </div>
          </AnimatedCard>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Blog;
