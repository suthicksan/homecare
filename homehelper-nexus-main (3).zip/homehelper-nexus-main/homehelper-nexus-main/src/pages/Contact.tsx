
import { useState } from "react";
import { AnimatedCard } from "@/components/ui/AnimatedCard";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast.success("Your message has been sent! We'll get back to you soon.");
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <section className="py-24 bg-white dark:bg-gray-900">
          <div className="container mx-auto px-6 md:px-8">
            <AnimatedCard>
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
                <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                  Have questions or need assistance? We're here to help! Reach out to our team and we'll get back to you as soon as possible.
                </p>
              </div>
            </AnimatedCard>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <AnimatedCard delay={100}>
                <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8">
                  <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Your Name
                      </label>
                      <input
                        id="name"
                        name="name"
                        type="text"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary bg-white dark:bg-gray-900"
                        placeholder="Enter your full name"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Email Address
                      </label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary bg-white dark:bg-gray-900"
                        placeholder="Enter your email"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Subject
                      </label>
                      <select
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary bg-white dark:bg-gray-900"
                      >
                        <option value="">Select a subject</option>
                        <option value="general">General Inquiry</option>
                        <option value="support">Customer Support</option>
                        <option value="feedback">Feedback</option>
                        <option value="partnership">Partnership Opportunity</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        required
                        rows={4}
                        className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-primary/50 focus:border-primary bg-white dark:bg-gray-900"
                        placeholder="How can we help you?"
                      ></textarea>
                    </div>
                    
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full"
                    >
                      {isSubmitting ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                          Sending...
                        </div>
                      ) : (
                        "Send Message"
                      )}
                    </Button>
                  </form>
                </div>
              </AnimatedCard>

              <div className="space-y-8">
                <AnimatedCard delay={200}>
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8">
                    <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <div className="w-5 h-5 rounded bg-gray-300 dark:bg-gray-600"></div>
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-lg font-semibold">Email</h3>
                          <p className="text-gray-600 dark:text-gray-300">support@homehelp.com</p>
                          <p className="text-gray-600 dark:text-gray-300">info@homehelp.com</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <div className="w-5 h-5 rounded bg-gray-300 dark:bg-gray-600"></div>
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-lg font-semibold">Phone</h3>
                          <p className="text-gray-600 dark:text-gray-300">+1 (555) 123-4567</p>
                          <p className="text-gray-600 dark:text-gray-300">Mon-Fri: 9am-6pm EST</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <div className="w-5 h-5 rounded bg-gray-300 dark:bg-gray-600"></div>
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-lg font-semibold">Address</h3>
                          <p className="text-gray-600 dark:text-gray-300">
                            123 HomeHelp Avenue<br />
                            Suite 456<br />
                            San Francisco, CA 94105
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </AnimatedCard>
                
                <AnimatedCard delay={300}>
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8">
                    <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">How do I book a service?</h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          You can book a service by navigating to our services page, selecting the service you need, and following the booking steps.
                        </p>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2">What is your cancellation policy?</h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          You can cancel a booking up to 24 hours before the scheduled service without any charges.
                        </p>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2">How are your service providers vetted?</h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          All service providers undergo a thorough background check, skills verification, and must maintain high customer ratings.
                        </p>
                      </div>
                    </div>
                  </div>
                </AnimatedCard>
              </div>
            </div>
            
            <AnimatedCard delay={400}>
              <div className="mt-16 rounded-xl overflow-hidden">
                <div className="aspect-w-16 aspect-h-6 w-full bg-gray-200 dark:bg-gray-700 image-loading"></div>
              </div>
            </AnimatedCard>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Contact;
